from .version import __version__

print('hello')

def main():
  print('main')
