# TCRDiscord

Various utilities for working with the `hikari` library and the Discord API.


