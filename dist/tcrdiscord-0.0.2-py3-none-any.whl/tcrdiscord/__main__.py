import sys

if '--syntax-test-only' in sys.argv:
  sys.exit(0)
